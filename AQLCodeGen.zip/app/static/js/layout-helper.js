/*******************************************************************************
 * Profile Helper Functions
 *******************************************************************************/

var layoutHelperFunctions = (function () {
  var init = function () {};

  // Validate numeric input using Globalize JS for i18n for values up to 999
  var validateInputNumber = function (inputNumber, idName) {
    // Empty string - Users clicks in the box, empties it and then clicks outside.
    if (!inputNumber || !inputNumber.trim()) {
      return 0;
    }

    // Remove spaces from user input
    if (inputNumber.indexOf(' ') != -1) {
      inputNumber = inputNumber.replace(' ', '');
    }
    // Both comma and decimal are entererd
    if (inputNumber.indexOf(',') != -1 && inputNumber.indexOf('.') != -1) {
      return -1;
    }
    // More than one comma is entered
    if (inputNumber.indexOf(',') != -1) {
      if ((inputNumber.match(/,/g) || []).length > 1) {
        return -1;
      }
    }
    // More than one decimal point is entered
    if (inputNumber.indexOf('.') != -1) {
      if ((inputNumber.match(/\./g) || []).length > 1) {
        return -1;
      }
    }
    // Parse comma
    if (inputNumber.indexOf(',') != -1) {
      var parsedNum = inputNumber.replace(',', '.');
      if (isEngFormat(inputNumber, parsedNum)) {
        return -1;
      }
      return validateDecimalInput(parsedNum, idName);
    }
    // Parse decimal
    else if (inputNumber.indexOf('.') != -1) {
      if (!isEngFormat(inputNumber, inputNumber)) {
        return -1;
      }
      return validateDecimalInput(inputNumber, idName);
    }
    // Parse Integer
    else {
      return Number(inputNumber);
    }
  };

  // Private helper function to validate input up to 10 using globalize js for i18n numeric input
  var validateDecimalInput = function (inputNumber, idName) {
    // Check if it's a number
    if (!$.isNumeric(Number(inputNumber))) {
      return -1;
    }
    // Check if zeros after demial point
    if (Math.floor(inputNumber) == inputNumber) {
      var outputValue = Number(parseInt(inputNumber));
      idName.val(layoutHelperFunctions.formatNumber(outputValue));
      return outputValue;
    }
    return Number(inputNumber);
  };

  // [GVT] Wrapper for NumberParser in order to avoid multiple grabs of cldr_locale.
  var parseGlobalValue = function (num) {
    return Globalize($('#cldrLocale').val()).numberParser({})(num);
  };

  var parseEnglishValue = function (num) {
    return Globalize('en').numberParser({})(num);
  };

  // [GVT] Check to see if input value is entered using English formatting (. decimals and , thousands)
  var isEngFormat = function (original, parsed) {
    if (
      $('#cldrLocale').val() === 'en' ||
      $('#cldrLocale').val() === 'ja' ||
      $('#cldrLocale').val() === 'zh' ||
      $('#cldrLocale').val() === 'ko'
    )
      return true;
    if ($.isNumeric(original.replace(/,/g, '')) && !$.isNumeric(parsed)) {
      return true;
    }
    return false;
  };

  // Shorten number to thousands, millions, billions, etc.
  // E.g. 1500 => 1.50k
  // input: num - numeric value or string numeric value,
  //        digits - approximation digits after the dot
  // output: formatted numeric value string
  var formatNumericValue = function (num, digits) {
    var si = [
        { value: 1e6, symbol: 'm' },
        { value: 1e3, symbol: 'k' },
      ],
      i;
    for (i = 0; i < si.length; i++) {
      if (num >= si[i].value) {
        return (num / si[i].value).toFixed(digits).replace(/\.0+$|(\.[0-9]*[1-9])0+$/, '$1') + si[i].symbol;
      }
    }
    if (num % 1 == 0) {
      return (num = parseInt(num, 10).toString());
    }
    return num.toString();
  };

  // [GVT] Takes in a statistic and returns data according to cultural preference selected by the local
  // rounds the vlaue and adds K (thousands), M (millions)
  var formatStatistic = function (statistic, noDecimals = false) {
    if (typeof statistic !== 'number') {
      statistic = Number(statistic);
    }
    if (!statistic) {
      // Number Formatter doesn't handle zeroes.
      return 0;
    }
    var compact, max_sig_dig, stat_len, stat_len_mod;
    stat_len = statistic.toString().length;
    if (stat_len && statistic > 999) {
      compact = 'short';
      stat_len_mod = stat_len % 3;
      if (noDecimals) max_sig_dig = stat_len_mod ? stat_len_mod : 2;
      else max_sig_dig = stat_len_mod ? stat_len_mod + 1 : 2;
    } else {
      compact = null;
      max_sig_dig = 4;
    }
    return Globalize($('#cldrLocale').val()).numberFormatter({
      compact: compact,
      minimumSignificantDigits: 1,
      maximumSignificantDigits: max_sig_dig,
    })(statistic);
  };

  // [GVT] Takes in a number to parse and returns data according to cultural preference selected by the local
  var formatNumber = function (statistic) {
    if (typeof statistic !== 'number') {
      statistic = Number(statistic);
    }
    if (!statistic) {
      // Number Formatter doesn't handle zeroes.
      return 0;
    }
    return Globalize($('#cldrLocale').val()).formatNumber(statistic, {
      minimumSignificantDigits: 1,
      maximumSignificantDigits: 9,
    });
  };

  //Private method. Opens a page in a window or tab

  function windowOrTab(url, windowName, openInTab) {
    if (openInTab) {
      return top.setActiveTab(tabName, url);
    } else {
      var w;
      if (windowName) {
        w = window.open('/console/' + url, windowName);
      } else {
        w = window.open('/console/' + url, '_blank');
      }
      // seems popup blockers in some browsers will return null or undefined for the window.open() call
      // adding check here for that case
      if (w === null || w === undefined) {
        // TODO: if we ever get a notification system add code here to notify the user to turn off popup blocker
        console.log('Browser blocked the call to open a new window, check popup blocker settings.');
      } else {
        w.focus();
      }
    }
  }

  /**
   * Runs an event search with the specified AQL string, either in a new window or the Event Viewer tab
   *
   * @param aql Required. The AQL string to execute in the search.
   */
  var open_event_search = function (aql) {
    var url =
      'do/ariel/arielSearch?appName=EventViewer&pageId=EventList&dispatch=performSearch&value(searchMode)=AQL&value(timeRangeType)=aqlTime' +
      '&value(aql)=' +
      encodeURIComponent(aql);

    return windowOrTab(url, 'uba_event_search');
  };

  var open_offense = function (offense_id) {
    var url = 'qradar/jsp/QRadar.jsp?appName=Sem&pageId=OffenseSummary&summaryId=' + encodeURIComponent(offense_id);
    return windowOrTab(url, 'uba_offense_search');
  };

  var open_asset = function (asset_id) {
    var url =
      'do/assetprofile/AssetDetails?dispatch=viewAssetDetails&assetId=' +
      encodeURIComponent(asset_id) +
      '&listName=vulnList&addNavigationButtons=true&listPageNumber=1&listPageSize=40&listSorting=&listOrderBy=';
    return windowOrTab(url, 'uba_asset_search');
  };

  var open_asset_by_ip = function (ip_address) {
    var url =
      'do/assetprofile/AssetDetails?dispatch=viewAssetDetailsFromIp&ipAddress=' +
      encodeURIComponent(ip_address) +
      '&domainId=0&listName=vulnList&addNavigationButtons=true&listPageNumber=1&listPageSize=40&listSorting=&listOrderBy=';
    return windowOrTab(url);
  };

  /**
   * Prevent popup blockers by opening the window before doing the ajax call
   **/
  var pre_open_window = function (windowName) {
    return windowOrTab('about:blank', windowName);
  };

  /******************************************
     * Take a number of millisonds and return an object {d,h,m,s}
     * This object represents the numbesr of days, hours, minutes, and seconds of time passed in the milliseconds

     * @param millis: number milliseconds to calulate for
     ******************************************/
  var millisToDaysHoursMinutes = function (millis) {
    var d, h, m, s;
    s = Math.floor(millis / 1000);
    m = Math.floor(s / 60);
    s = s % 60;
    h = Math.floor(m / 60);
    m = m % 60;
    d = Math.floor(h / 24);
    h = h % 24;

    return { d: d, h: h, m: m, s: s };
  };

  /***************
   **
   ** Category Card Helper methods
   **
   ***************/
  var stopProp = function (e) {
    e.stopPropagation();
  };
  var openOffense = function (e) {
    var oid = $(this).data('oid');
    if (!isNaN(oid)) {
      layoutHelperFunctions.open_offense(oid);
    }
  };
  var getStyleForMagnitudeBar = function (value, availableWidth) {
    var width = value === 0 ? '2px' : (value / 10) * availableWidth + 'px';
    var color = getMagnitudeColor(value);
    var result = {};
    result['width'] = width;
    result['background-color'] = color;
    return result;
  };
  var getMagnitudeColor = function (magnitude) {
    var color = '';
    if (magnitude > 5) {
      //High magnitude (6-10)
      color = '#dc0000';
    } else if (magnitude > 2) {
      //Med magnitude (3-6)
      color = '#FD8C00';
    } //Low (1-2) magnitude
    else {
      color = '#FDC500';
    }
    return color;
  };

  var statusColorRange = function (currentValue, thresholdValue) {
    const colorRange = ['#c6c6c6', '#f1c21b', '#ff832b', '#fa4d56', '#780000']; //grey, yellow, orange, red, dark red

    var color = '';
    if (!thresholdValue || isNaN(currentValue) || currentValue < 0) {
      color = colorRange[0]; //grey
    } else {
      var riskRatio = currentValue / thresholdValue;

      if (riskRatio > 1) {
        color = colorRange[4];
      } else if (riskRatio > 0.75) {
        color = colorRange[3];
      } else if (riskRatio > 0.5) {
        color = colorRange[2];
      } else if (riskRatio > 0.25) {
        color = colorRange[1];
      } else {
        color = colorRange[0];
      }
    }

    return color;
  };

  // Show user info when hover over a user
  var userOverHover = function () {
    var popoverSettings = {
      placement: 'right',
      container: 'body',
      trigger: 'hover',
      selector: '[data-toggle="user-popover"]',
      html: true,
      content: function () {
        var userID = $(this).parent().attr('id');
        var div_id = $.now();
        return '<div id="popover-info-' + div_id + '">' + getUserData(userID, div_id) + '</div>';
      },
    };

    // Bind popover
    $('body').popover(popoverSettings);

    function htmlEncode(value) {
      //create a in-memory div, set it's inner text(which jQuery automatically encodes)
      //then grab the encoded contents back out.  The div never exists on the page.
      return $('<div/>').text(value).html();
    }

    function htmlDecode(value) {
      return $('<div/>').html(value).text();
    }
  };

  var isIE = function () {
    var ua = window.navigator.userAgent;
    if (ua.indexOf('MSIE') > 0 || ua.indexOf('Trident') > 0 || ua.indexOf('Edge') > 0) {
      return true;
    } else {
      return false;
    }
  };

  var generateEvent = function (eventName, context) {
    var event;

    if (isIE()) {
      event = document.createEvent('Event');
      event.initEvent(eventName, true, true);
    } else {
      event = new Event(eventName);
    }

    context.dispatchEvent(event);
  };

  // Event listener for "go to top" event
  // input:
  // offset = browser window scroll (in pixels) after which the "back to top" link is shown
  // offset_opacity = browser window scroll (in pixels) after which the "back to top" link opacity is reduced
  // scroll_top_duration = duration of the top scrolling animation (in ms)
  //
  // output: none
  var gotoTopButtonListener = function (offset, offset_opacity, scroll_top_duration) {
    //grab the "back to top" link
    $back_to_top = $('.goto-top');

    //hide or show the "back to top" link
    $(window).scroll(function () {
      $(this).scrollTop() > offset
        ? $back_to_top.addClass('goto-top-visible')
        : $back_to_top.removeClass('goto-top-visible goto-top-fade-out');
      if ($(this).scrollTop() > offset_opacity) {
        $back_to_top.addClass('goto-top-fade-out');
      }
    });

    //smooth scroll to top
    $back_to_top.on('click', function (event) {
      event.preventDefault();

      $('body,html').animate(
        {
          scrollTop: 0,
        },
        scroll_top_duration
      );
    });
  };

  var validateIPaddress = function (ipaddress) {
    if (
      /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(
        ipaddress
      )
    ) {
      return true;
    }
    return false;
  };

  return {
    init: init,
    formatNumericValue: formatNumericValue,
    formatStatistic: formatStatistic,
    formatNumber: formatNumber,
    validateInputNumber: validateInputNumber,
    isEngFormat: isEngFormat,
    parseGlobalValue: parseGlobalValue,
    parseEnglishValue: parseEnglishValue,
    open_event_search: open_event_search,
    open_offense: open_offense,
    open_asset: open_asset,
    open_asset_by_ip: open_asset_by_ip,
    pre_open_window: pre_open_window,
    statusColorRange: statusColorRange,
    userOverHover: userOverHover,
    generateEvent: generateEvent,
    gotoTopButtonListener: gotoTopButtonListener,
    validateIPaddress: validateIPaddress,
  };
})();
